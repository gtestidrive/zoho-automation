import type { Locator, Page } from '@playwright/test';

export class ExportDownloadLocators {
  items(page: Page): Locator {
    return page.locator('downloads-item');
  }

  async readItems(page: Page) {
    return this.items(page).evaluateAll((items) => items.map((item) => {
      if (!('data' in item) || typeof item.data !== 'object' || item.data === null) {
        return null;
      }
      const data = item.data;
      if (!('id' in data) || typeof data.id !== 'string'
        || !('fileName' in data) || typeof data.fileName !== 'string'
        || !('isInsecure' in data) || typeof data.isInsecure !== 'boolean') {
        throw new Error('Chrome download item has an unsupported data format.');
      }
      return { id: data.id, fileName: data.fileName, isInsecure: data.isInsecure };
    }));
  }

  keep(item: Locator): Locator {
    return item.getByRole('button', { name: /^keep(?: anyway)?$/i });
  }

  menu(item: Locator): Locator {
    return item.locator('#more-actions');
  }
}
