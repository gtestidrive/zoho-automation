import { expect, type Locator, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { ExportDownloadPage } from '../../export/export-download.page';
import { backupLabels } from '../backup/backup.labels';
import type { DriveSnapshotEntry } from '../backup/backup.page';
import type { WorkDriveEntry } from '../api/zoho-workdrive.api';
import {
  chooseRandomDriveExportEntries,
  DriveExportAssertions,
  readDriveExportArchiveEntries,
  readDriveExportArchiveFiles,
  verifyDriveExportContents,
} from './drive-export.assertions';
import { exportPatterns } from './drive-export.labels';
import { DriveExportLocators } from './drive-export.locators';

function log(message: string): void {
  console.log(`[${new Date().toISOString()}] ${message}`);
}

export type DriveExportResult = {
  selectedEntries: DriveSnapshotEntry[];
  status: 'Active';
  archivePath: string;
  archiveEntries: string[];
};

type ExportCandidate = DriveSnapshotEntry & { row: Locator; checkbox: Locator; pageIndex: number };
type ExportHistoryRow = { text: string; cells: string[]; locator: Locator };

export type WorkDriveExportContext = {
  product: string;
  typeColumn: number;
  openRoot: (name: string) => Promise<void>;
  readCurrentFolder: (parentPath: string[]) => Promise<DriveSnapshotEntry[]>;
  listSource: () => Promise<WorkDriveEntry[]>;
  downloadSource: (fileId: string) => Promise<Uint8Array>;
};

export class WorkDriveExportPage {
  private readonly locators: DriveExportLocators;
  private readonly assertions: DriveExportAssertions;
  constructor(
    private readonly page: Page,
    locators: DriveExportLocators,
    private readonly context: WorkDriveExportContext,
  ) {
    this.locators = locators;
    this.assertions = new DriveExportAssertions(this.locators, this.context.product);
  }

  async exportRandomSnapshotEntriesAndWait(
    userEmail: string,
    downloadDirectory: string,
  ): Promise<DriveExportResult> {
    await this.context.openRoot(userEmail);
    const user = { email: userEmail };

    await this.openExportsTab();
    const previousText = new Set((await this.readExportHistoryRows()).map(({ text }) => text));
    await this.context.openRoot(user.email);

    const candidates = await this.getExportCandidates();
    const selectedEntries = chooseRandomDriveExportEntries(candidates);
    this.assertions.expectFolderSelected(selectedEntries);
    const snapshotEntries: DriveSnapshotEntry[] = [];
    for (const entry of selectedEntries) {
      snapshotEntries.push({ name: entry.name, path: entry.path, type: entry.type });
      if (entry.type === 'Folder') {
        await this.openSnapshotPage(entry.pageIndex);
        log(`[${this.context.product}] Scanning only selected folder "${entry.path}" and its descendants.`);
        await this.locators.snapshot.cellAt(entry.row, 1).click();
        await expect(this.locators.snapshot.snapshotBreadcrumb(entry.name).last()).toBeVisible();
        snapshotEntries.push(...await this.context.readCurrentFolder(entry.path.split('\\')));
        await this.context.openRoot(user.email);
      }
    }
    for (const entry of selectedEntries) {
      await this.openSnapshotPage(entry.pageIndex);
      await expect(entry.checkbox).toBeEnabled();
      await entry.checkbox.check();
    }
    for (const entry of selectedEntries) {
      await this.openSnapshotPage(entry.pageIndex);
      await expect(entry.checkbox, `Selection must persist for "${entry.path}" across snapshot pages.`).toBeChecked();
    }
    log(`[${this.context.product}] Randomly selected ${selectedEntries.length} of ${candidates.filter(({ type }) => type === 'Folder').length} folders across all root snapshot pages.`);
    const selectedPaths = selectedEntries.map(({ path }) => path).join(', ');

    await expect(this.locators.snapshotExportButton).toBeEnabled();
    log(`[${this.context.product}] Preparing export for ${selectedPaths}.`);
    await this.locators.snapshotExportButton.click();
    await this.assertions.expectExportDialogReady();
    const exportStartedAt = Date.now();
    await this.locators.confirmExportButton.click();
    await this.assertions.expectExportDialogClosed();
    log(`[${this.context.product}] Submitted export for ${selectedPaths}.`);

    await this.openExportsTab();
    let latestStatus: string | undefined;
    let newExportText = '';
    await expect.poll(async () => {
      await this.refreshExportsTab();
      const newRow = (await this.readExportHistoryRows()).find(({ text }) => !previousText.has(text));
      if (!newRow) {
        return '';
      }

      const status = newRow.cells.find((cell) => exportPatterns.status.test(cell))?.trim();
      if (status && exportPatterns.failed.test(status)) {
        throw new Error(`${this.context.product} export failed for ${user.email} after selecting ${selectedPaths}. Row: ${newRow.text}`);
      }
      latestStatus = status;
      newExportText = newRow.text;
      return status ?? '';
    }, {
      timeout: 10 * 60_000,
      intervals: [2_000, 5_000],
      message: `Waiting for the ${this.context.product} export for ${user.email} to become Active.`,
    }).toMatch(exportPatterns.active);

    const elapsedSeconds = ((Date.now() - exportStartedAt) / 1000).toFixed(1);
    log(`[${this.context.product}] Export for ${user.email} reached ${latestStatus} in ${elapsedSeconds}s.`);

    await this.refreshExportsTab();
    const completedRows = (await this.readExportHistoryRows()).filter(({ text }) => text === newExportText);
    if (completedRows.length !== 1) {
      throw new Error(
        `Expected one completed Drive export history row for ${user.email}, found ${completedRows.length}.`,
      );
    }
    const downloadAction = this.locators.downloadAction(completedRows[0].locator);
    await expect(downloadAction).toBeEnabled({ timeout: 30_000 });
    const { archivePath, archiveEntries } = await this.downloadAndSave(downloadAction, downloadDirectory);
    const archiveFiles = readDriveExportArchiveFiles(await readFile(archivePath));
    this.assertions.expectSelectionInArchive(selectedEntries, snapshotEntries, archiveEntries, archiveFiles);

    const { issues, verifiedFiles } = await verifyDriveExportContents(
      selectedEntries,
      await this.context.listSource(),
      archiveFiles,
      this.context.downloadSource,
      `${this.context.product}: ${user.email}`,
    );
    console.table([{
      Product: this.context.product,
      Source: user.email,
      SelectedEntries: selectedEntries.length,
      ArchiveEntries: archiveEntries.length,
      VerifiedFiles: verifiedFiles,
      Issues: issues.length,
    }]);
    this.assertions.expectNoContentIssues(issues);
    return { selectedEntries, status: 'Active', archivePath, archiveEntries };
  }

  private async downloadAndSave(
    downloadAction: Locator,
    downloadDirectory: string,
  ): Promise<{ archivePath: string; archiveEntries: string[] }> {
    const archivePath = await new ExportDownloadPage(this.page, this.context.product)
      .downloadZip(downloadAction, downloadDirectory);
    const archiveEntries = readDriveExportArchiveEntries(await readFile(archivePath));
    log(`[${this.context.product}] Downloaded and inspected export ZIP at ${archivePath} (${archiveEntries.length} entries).`);
    return { archivePath, archiveEntries };
  }

  private async openExportsTab(): Promise<void> {
    await expect(this.locators.exportsTab).toBeVisible({ timeout: 30_000 });
    await this.locators.exportsTab.click();
    await expect(this.locators.exportsTab).toHaveAttribute('aria-selected', 'true');
    await expect(this.locators.exportsTable).toBeVisible({ timeout: 30_000 });
  }

  private async refreshExportsTab(): Promise<void> {
    await this.page.reload({ waitUntil: 'domcontentloaded' });
    await this.openExportsTab();
  }

  private async readExportHistoryRows(): Promise<ExportHistoryRow[]> {
    await expect(this.locators.exportsTab).toHaveAttribute('aria-selected', 'true');
    await expect(this.locators.exportsTable).toBeVisible({ timeout: 30_000 });
    await expect(this.locators.exportsLoading).toBeHidden({ timeout: 60_000 });
    const rows = this.locators.exportRows();
    const result: ExportHistoryRow[] = [];
    for (let index = 1; index < await rows.count(); index++) {
      const row = rows.nth(index);
      const cells = (await this.locators.snapshot.rowCells(row).allInnerTexts()).map((cell) => cell.trim());
      result.push({ text: cells.join(' | '), cells, locator: row });
    }
    return result;
  }

  private async openSnapshotPage(pageIndex: number): Promise<void> {
    const { snapshot } = this.locators;
    await expect(snapshot.snapshotLoading).toBeHidden({ timeout: 30_000 });
    await expect(snapshot.snapshotRange).toBeVisible({ timeout: 30_000 });
    while (!await snapshot.snapshotPreviousPageButton.isDisabled()) {
      const range = await snapshot.snapshotRange.innerText();
      await snapshot.snapshotPreviousPageButton.click();
      await expect(snapshot.snapshotRange).not.toHaveText(range);
      await expect(snapshot.snapshotLoading).toBeHidden({ timeout: 30_000 });
    }
    for (let index = 0; index < pageIndex; index++) {
      await expect(snapshot.snapshotNextPageButton).toBeEnabled();
      const range = await snapshot.snapshotRange.innerText();
      await snapshot.snapshotNextPageButton.click();
      await expect(snapshot.snapshotRange).not.toHaveText(range);
      await expect(snapshot.snapshotLoading).toBeHidden({ timeout: 30_000 });
    }
  }

  private async getExportCandidates(): Promise<ExportCandidate[]> {
    const candidates: ExportCandidate[] = [];
    await this.openSnapshotPage(0);
    for (let pageIndex = 0; ; pageIndex++) {
      candidates.push(...await this.getVisibleExportCandidates(pageIndex));
      const { snapshot } = this.locators;
      if (await snapshot.snapshotNextPageButton.isDisabled()) {
        break;
      }
      const range = await snapshot.snapshotRange.innerText();
      await snapshot.snapshotNextPageButton.click();
      await expect(snapshot.snapshotRange).not.toHaveText(range);
    }
    return candidates;
  }

  private async getVisibleExportCandidates(pageIndex: number): Promise<ExportCandidate[]> {
    const { snapshot } = this.locators;
    await expect(snapshot.snapshotLoading).toBeHidden({ timeout: 30_000 });
    await expect(snapshot.snapshotRange).toBeVisible({ timeout: 30_000 });
    const rows = snapshot.tableRows(snapshot.snapshotTable);
    const candidates: ExportCandidate[] = [];

    for (let index = 1; index < await rows.count(); index++) {
      const row = rows.nth(index);
      const cells = await snapshot.rowCells(row).allInnerTexts();
      const name = cells[1]?.trim() ?? '';
      const type = cells[this.context.typeColumn]?.trim();
      if (!name || (type !== backupLabels.folderType && type !== backupLabels.fileType)) {
        continue;
      }

      const checkbox = row.getByRole('checkbox');
      if (await checkbox.count() !== 1 || !(await checkbox.isEnabled())) {
        continue;
      }
      candidates.push({ name, type, path: name, row, checkbox, pageIndex });
    }
    return candidates;
  }
}
