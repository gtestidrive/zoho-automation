import { expect, type Download, type Locator, type Page } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { ExportDownloadLocators } from './export-download.locators';

export class ExportDownloadPage {
  private readonly locators = new ExportDownloadLocators();

  constructor(private readonly page: Page, private readonly product: string) {}

  async downloadZip(action: Locator, directory: string): Promise<string> {
    let downloadsPage: Page | undefined;
    let download: Download | undefined;
    let saving: Promise<void> | undefined;
    let archivePath: string | undefined;
    let saveError: unknown;
    let failed = false;
    const onDownload = (value: Download): void => { download = value; };
    this.page.on('download', onDownload);
    try {
      const headless = await this.page.evaluate(() => navigator.userAgent.includes('HeadlessChrome'));
      if (!headless) {
        downloadsPage = await this.page.context().newPage();
        await downloadsPage.goto('chrome://downloads/');
        await expect(downloadsPage.locator('downloads-manager')).toBeAttached();
      }
      const previousIds = new Set(downloadsPage
        ? (await this.locators.readItems(downloadsPage)).flatMap((item) => item ? [item.id] : [])
        : []);
      await this.page.bringToFront();
      await action.click();
      await expect.poll(async () => {
        if (downloadsPage) {
          await this.keepNewInsecureZip(downloadsPage, previousIds);
        }
        if (download && !saving) {
          saving = this.saveZip(download, directory).then((path) => {
            archivePath = path;
          }, (error: unknown) => {
            saveError = error;
            failed = true;
          });
        }
        if (failed) {
          throw saveError;
        }
        return archivePath !== undefined;
      }, {
        timeout: 180_000,
        intervals: [500, 1_000],
        message: `Waiting for ${this.product} ZIP download, accepting Chrome Keep for an insecure ZIP if present.`,
      }).toBe(true);
      if (!archivePath) {
        throw new Error(`${this.product} download finished without a saved ZIP.`);
      }
      console.log(`[${new Date().toISOString()}] [${this.product}] Downloaded ZIP: ${archivePath}`);
      return archivePath;
    } finally {
      this.page.off('download', onDownload);
      await downloadsPage?.close();
    }
  }

  private async keepNewInsecureZip(page: Page, previousIds: Set<string>): Promise<void> {
    const blocked = (await this.locators.readItems(page)).flatMap((item, index) =>
      item && !previousIds.has(item.id) && item.isInsecure && /\.zip$/i.test(item.fileName)
        ? [{ ...item, index }] : []);
    if (blocked.length > 1) {
      throw new Error(`Multiple new insecure ZIP downloads found; cannot identify ${this.product} safely.`);
    }
    const item = blocked[0];
    if (!item) {
      return;
    }
    const row = this.locators.items(page).nth(item.index);
    const keep = this.locators.keep(row);
    if (!await keep.isVisible()) {
      const menu = this.locators.menu(row);
      if (!await menu.isVisible()) {
        return;
      }
      await menu.click();
    }
    await expect(keep).toBeVisible({ timeout: 5_000 });
    await keep.click();
    previousIds.add(item.id);
    console.log(`[${this.product}] Clicked Chrome Keep for "${item.fileName}".`);
  }

  private async saveZip(download: Download, directory: string): Promise<string> {
    const filename = download.suggestedFilename();
    if (!filename || basename(filename) !== filename || !/\.zip$/i.test(filename)) {
      throw new Error(`Expected ${this.product} ZIP archive, received "${filename}".`);
    }
    await mkdir(directory, { recursive: true });
    const archivePath = join(directory, `export-${Date.now()}-${filename}`);
    await download.saveAs(archivePath);
    return archivePath;
  }
}
