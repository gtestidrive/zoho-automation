import { expect } from '@playwright/test';
import { unzipSync } from 'fflate';
import { createHash } from 'node:crypto';
import type { WorkDriveEntry } from '../api/zoho-workdrive.api';
import type { DriveSnapshotEntry } from '../backup/backup.page';
import type { DriveExportLocators } from './drive-export.locators';

export type DriveExportContentIssue = { path: string; problem: string };

export class NoSelectableExportFoldersError extends Error {}

export class DriveExportAssertions {
  constructor(
    private readonly locators: DriveExportLocators,
    private readonly product = 'Drive export',
  ) {}

  async expectExportDialogReady(): Promise<void> {
    await expect(this.locators.exportDialog).toBeVisible({ timeout: 15_000 });
    await expect(this.locators.selectedItemsRadio).toBeChecked();
  }

  async expectExportDialogClosed(): Promise<void> {
    await expect(this.locators.exportDialog).toBeHidden({ timeout: 30_000 });
  }

  expectFolderSelected(selectedEntries: Array<Pick<DriveSnapshotEntry, 'type'>>): void {
    if (!selectedEntries.some(({ type }) => type === 'Folder')) {
      throw new NoSelectableExportFoldersError('The snapshot has no selectable folder to export; at least one real folder must be selected.');
    }
  }

  expectSelectionInArchive(
    selectedEntries: DriveSnapshotEntry[],
    snapshotEntries: DriveSnapshotEntry[],
    archiveEntries: string[],
    archiveFiles: Map<string, Uint8Array>,
  ): void {
    console.log(`[${new Date().toISOString()}] [${this.product} verification 1/2] Comparing downloaded names, paths and types with C2C snapshot items.`);
    const expected = snapshotEntries.filter((entry) => selectedEntries.some((selected) =>
      entry.path === selected.path
      || selected.type === 'Folder' && entry.path.startsWith(`${selected.path}\\`)));
    for (const selected of selectedEntries) {
      if (!expected.some(({ path, type }) => path === selected.path && type === selected.type)) {
        throw new Error(`Selected C2C item "${selected.path}" (${selected.type}) was not found in the captured snapshot inventory.`);
      }
    }
    const downloaded: Array<{ path: string; type: DriveSnapshotEntry['type'] }> = [];
    for (const path of archiveEntries) {
      const type = archiveFiles.has(normalizeArchivePath(path)) ? 'File' : 'Folder';
      downloaded.push({ path, type });
      const parts = path.split('\\');
      for (let length = 1; length < parts.length; length++) {
        downloaded.push({ path: parts.slice(0, length).join('\\'), type: 'Folder' });
      }
    }
    const rows = expected.map((entry) => {
      const matches = downloaded.filter(({ path, type }) => type === entry.type
        && (path === entry.path || path.endsWith(`\\${entry.path}`)));
      return {
        C2CName: entry.name,
        C2CPath: entry.path,
        C2CType: entry.type,
        DownloadPath: matches[0]?.path ?? '(missing or name/path/type differs)',
        NamePathTypeMatch: matches.length > 0,
      };
    });
    console.table(rows);
    const missing = rows.filter(({ NamePathTypeMatch }) => !NamePathTypeMatch);
    console.log(`[${new Date().toISOString()}] [${this.product} verification 1/2] C2C items=${rows.length}, matched=${rows.length - missing.length}, missing/mismatched=${missing.length}.`);
    if (missing.length > 0) {
      throw new Error(
        `Drive export ZIP does not match C2C snapshot names, paths or types: ${missing.map(({ C2CPath }) => C2CPath).join(', ')}.`,
      );
    }
  }

  expectNoContentIssues(issues: DriveExportContentIssue[]): void {
    if (issues.length > 0) {
      console.table(issues);
      throw new Error(`Drive export ZIP differs from Zoho WorkDrive (${issues.length} issue(s)).`);
    }
  }
}

function normalizeArchivePath(path: string): string {
  return path.replace(/\//g, '\\').replace(/\\+$/, '').toLowerCase();
}

export function readDriveExportArchiveFiles(archive: Uint8Array): Map<string, Uint8Array> {
  let archiveFiles: Record<string, Uint8Array>;
  try {
    archiveFiles = unzipSync(archive);
  } catch (error) {
    throw new Error('Drive export is not a readable ZIP archive.', { cause: error });
  }
  return new Map(Object.entries(archiveFiles)
    .filter(([name]) => name && !name.endsWith('/'))
    .map(([name, data]) => [normalizeArchivePath(name), data]));
}

export function readDriveExportArchiveEntries(archive: Uint8Array): string[] {
  let archiveFiles: Record<string, Uint8Array>;
  try {
    archiveFiles = unzipSync(archive);
  } catch (error) {
    throw new Error('Drive export is not a readable ZIP archive.', { cause: error });
  }
  const entries = Object.keys(archiveFiles)
    .filter(Boolean)
    .map((entry) => entry.replace(/\//g, '\\').replace(/\\+$/, ''));
  if (entries.length === 0) {
    throw new Error('Drive export ZIP contains no files.');
  }
  return entries;
}

// Compares selected items and their Zoho descendants against the ZIP; tolerates an unknown top-level prefix in the ZIP.
export async function verifyDriveExportContents(
  selectedEntries: DriveSnapshotEntry[],
  sourceEntries: WorkDriveEntry[],
  archiveFiles: Map<string, Uint8Array>,
  downloadSource: (fileId: string) => Promise<Uint8Array>,
  product = 'Drive export',
): Promise<{ issues: DriveExportContentIssue[]; verifiedFiles: number }> {
  console.log(`[${new Date().toISOString()}] [${product} verification 2/2] Comparing downloaded file sizes and SHA-256 checksums with live Zoho originals.`);
  const issues: DriveExportContentIssue[] = [];
  let verifiedFiles = 0;
  const findArchiveKey = (path: string): string | undefined => {
    const wanted = path.toLowerCase();
    return [...archiveFiles.keys()].find((key) => key === wanted || key.endsWith(`\\${wanted}`));
  };

  for (const selected of selectedEntries) {
    const selectedPath = selected.path.toLowerCase();
    const expected = sourceEntries.filter((entry) => entry.type === 'File'
      && (selected.type === 'File'
        ? entry.path.toLowerCase() === selectedPath
        : entry.path.toLowerCase().startsWith(`${selectedPath}\\`)));
    const sourceItem = sourceEntries.find((entry) => entry.path.toLowerCase() === selectedPath);
    if (!sourceItem) {
      issues.push({ path: selected.path, problem: 'Selected item was not found in Zoho WorkDrive' });
      continue;
    }
    if (sourceItem.type !== selected.type) {
      issues.push({ path: selected.path, problem: `Type differs: C2C ${selected.type}, Zoho ${sourceItem.type}` });
    }

    const matchedKeys = new Set<string>();
    for (const file of expected) {
      const key = findArchiveKey(file.path);
      if (!key) {
        issues.push({ path: file.path, problem: 'Missing from export ZIP' });
        console.error(`[${product} verification 2/2] Missing downloaded file: "${file.path}". Checksum NOT verified.`);
        continue;
      }
      matchedKeys.add(key);
      const exported = archiveFiles.get(key);
      if (!exported) {
        throw new Error(`Drive export entry disappeared during verification: ${key}.`);
      }
      let original: Uint8Array;
      try {
        original = await downloadSource(file.id);
      } catch (error) {
        throw new Error(`Could not download Zoho original "${file.path}" for checksum verification.`, { cause: error });
      }
      const exportedChecksum = createHash('sha256').update(exported).digest('hex');
      const sourceChecksum = createHash('sha256').update(original).digest('hex');
      console.table([{
        Path: file.path,
        ExportBytes: exported.length,
        ZohoBytes: original.length,
        ExportSHA256: exportedChecksum,
        ZohoSHA256: sourceChecksum,
        Matches: exported.length === original.length && exportedChecksum === sourceChecksum,
      }]);
      if (exported.length !== original.length || exportedChecksum !== sourceChecksum) {
        issues.push({
          path: file.path,
          problem: `Content differs (ZIP ${exported.length} bytes, SHA-256 ${exportedChecksum}; `
            + `Zoho ${original.length} bytes, SHA-256 ${sourceChecksum})`,
        });
      } else {
        verifiedFiles++;
      }
    }

    if (selected.type === 'Folder') {
      const expectedPaths = new Set(expected.map((file) => file.path.toLowerCase()));
      for (const key of archiveFiles.keys()) {
        const inner = key.indexOf(`\\${selectedPath}\\`);
        const marker = key.startsWith(`${selectedPath}\\`) ? 0 : inner >= 0 ? inner + 1 : -1;
        if (marker < 0) {
          continue;
        }
        if (!expectedPaths.has(key.slice(marker)) && !matchedKeys.has(key)) {
          issues.push({ path: key, problem: 'Present in export ZIP but not in Zoho folder' });
        }
      }
    } else if (!findArchiveKey(selected.path) && expected.length === 0) {
      issues.push({ path: selected.path, problem: 'Missing from export ZIP' });
    }
  }
  console.log(`[${new Date().toISOString()}] [${product} verification 2/2] SHA-256 matched files=${verifiedFiles}, inventory/content issues=${issues.length}.`);
  return { issues, verifiedFiles };
}

export function missingDriveExportEntries(
  selectedEntries: DriveSnapshotEntry[],
  archiveEntries: string[],
): DriveSnapshotEntry[] {
  return selectedEntries.filter((entry) => !driveExportContainsEntry(archiveEntries, entry));
}

function driveExportContainsEntry(archiveEntries: string[], selected: DriveSnapshotEntry): boolean {
  const normalizedName = selected.name.trim().toLowerCase();
  return archiveEntries.some((entry) => {
    const normalizedPath = entry.replace(/\//g, '\\').toLowerCase();
    if (selected.type === 'File') {
      return normalizedPath === normalizedName || normalizedPath.endsWith(`\\${normalizedName}`);
    }
    return normalizedPath === normalizedName
      || normalizedPath.startsWith(`${normalizedName}\\`)
      || normalizedPath.includes(`\\${normalizedName}\\`)
      || normalizedPath.endsWith(`\\${normalizedName}`);
  });
}

export function chooseRandomDriveExportEntries<T extends Pick<DriveSnapshotEntry, 'type'>>(
  entries: T[],
  random: () => number = Math.random,
): T[] {
  const folders = entries.filter(({ type }) => type === 'Folder');
  if (folders.length === 0) {
    return [];
  }
  const count = 1 + Math.floor(random() * Math.min(3, folders.length));
  const selected: T[] = [];
  while (selected.length < count) {
    selected.push(folders.splice(Math.floor(random() * folders.length), 1)[0]);
  }
  return selected;
}
