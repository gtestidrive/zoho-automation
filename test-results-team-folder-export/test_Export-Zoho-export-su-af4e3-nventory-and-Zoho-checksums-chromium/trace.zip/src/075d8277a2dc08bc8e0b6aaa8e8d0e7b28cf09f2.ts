import { expect, test } from '@playwright/test';
import { zipSync, strToU8 } from 'fflate';
import { readFile } from 'node:fs/promises';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { homedir, tmpdir } from 'node:os';
import { join } from 'node:path';
import { setupDriveExport } from '../pages/drive/export/drive_export_config';
import { setupTeamFolderExport } from '../pages/team-folder/export/team_folder_export_config';
import { setupContactsExport } from '../pages/contacts/export/contacts_export_config';
import { openMailRecovery, signInToMailC2C } from '../pages/mail/backup/mail_backup_config';
import { compareMailExportMessages, readExportedMailMessages } from '../pages/mail/export/mail-export.comparison';

const exportSuiteEnabled = process.env.RUN_ZOHO_EXPORT_SUITE === '1';

test('reads Mail message headers from an export ZIP and preserves duplicate messages', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'mail-export-comparison-'));
  const zipPath = join(directory, 'inbox.zip');
  const message = [
    'From: Zoho Sender <sender@example.com>',
    'To: c2c@example.com',
    'Subject: =?UTF-8?B?SGVsbG8gV29ybGQ=?=',
    '',
    'Message body is not needed for metadata comparison.',
  ].join('\r\n');
  try {
    await writeFile(zipPath, zipSync({
      'Inbox/1.eml': strToU8(message),
      'Inbox/2.eml': strToU8(message),
    }, { level: 6 }));
    const exported = await readExportedMailMessages(zipPath);
    const native = [
      { from: 'sender@example.com', to: 'c2c@example.com', subject: 'Hello World', size: '1kb' },
      { from: 'sender@example.com', to: 'c2c@example.com', subject: 'Hello World', size: '1kb' },
    ];

    expect(exported).toHaveLength(2);
    expect(compareMailExportMessages(native, exported)).toEqual({ nativeOnly: [], exportOnly: [] });
    expect(compareMailExportMessages(native.slice(0, 1), exported)).toEqual({
      nativeOnly: [],
      exportOnly: [{ from: 'sender@example.com', to: 'c2c@example.com', subject: 'Hello World' }],
    });
    expect(compareMailExportMessages([{
      from: 'Zoho Sender &lt;sender@example.com&gt;',
      to: 'c2c@example.com&gt;',
      subject: 'Hello &#39;World&#39;',
      size: '1kb',
    }], [{
      from: 'sender@example.com',
      to: 'c2c@example.com',
      subject: "Hello 'World'",
    }])).toEqual({ nativeOnly: [], exportOnly: [] });
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test.describe('Zoho export suite', () => {
  test.describe.configure({ mode: 'serial' });

  test.beforeEach(async () => {
    test.skip(!exportSuiteEnabled, 'Opt in by setting RUN_ZOHO_EXPORT_SUITE=1 to run live exports.');
  });

  test('Drive export: randomly select snapshot files and folders, download ZIP, and verify selection', async ({ page }) => {
    test.setTimeout(20 * 60_000);

    const { email, exportPage } = await test.step(
      'Sign in and open Drive recovery',
      () => setupDriveExport(page),
    );

    const result = await test.step(
      'Export selected snapshot items, download the ZIP, and verify its contents',
      () => exportPage.exportRandomSnapshotEntriesAndWait(
        email,
        join(homedir(), 'Downloads', 'ZohoDriveExportInspection'),
      ),
    );

    await test.step('Verify the Drive export completed', async () => {
      expect(result.selectedEntries.length).toBeGreaterThan(0);
      expect(result.status).toBe('Active');
      expect(result.archiveEntries.length).toBeGreaterThan(0);
      expect(await readFile(result.archivePath)).toBeTruthy();
      console.log(`[Zoho C2C Drive] Preserved export ZIP for Explorer inspection: ${result.archivePath}`);
    });
  });

  test('Team Folder export: export random folders from every team and verify C2C inventory and Zoho checksums', async ({ page }) => {
    test.setTimeout(60 * 60_000);
    const { exportPage } = await test.step('Sign in and open Team Folder recovery', () =>
      setupTeamFolderExport(page));
    const teams = await test.step('Match every C2C team with Zoho WorkDrive', () =>
      exportPage.listMatchingTeams());
    test.setTimeout(Math.max(60 * 60_000, teams.length * 20 * 60_000));
    await test.step('Export and verify 1-3 random folders inside each team', () =>
      exportPage.exportEveryTeamAndVerify(
        teams,
        join(homedir(), 'Downloads', 'ZohoTeamFolderExportInspection'),
      ));
  });

  test('Contacts export: select real contacts, download VCF ZIP, and verify C2C and Zoho fields', async ({ page }) => {
    test.setTimeout(20 * 60_000);
    const { email, exportPage } = await test.step('Sign in and open Contacts recovery', () =>
      setupContactsExport(page));
    const result = await test.step('Export random contacts and verify downloaded fields with C2C and Zoho', () =>
      exportPage.exportRandomContactsAndVerify(
        email,
        join(homedir(), 'Downloads', 'ZohoContactsExportInspection'),
      ));
    expect(result.selectedContacts.length).toBeGreaterThan(0);
    expect(result.exportedContacts).toBe(result.selectedContacts.length);
    console.log(`[Contacts export] Preserved verified archive: ${result.archivePath}`);
  });

  test('Mail export: download Inbox and compare exported messages with Zoho Inbox', async ({ page }) => {
    test.setTimeout(30 * 60_000);

    const { email, mailPage, mailApi } = await test.step(
      'Sign in to C2C',
      () => signInToMailC2C(page),
    );
    await test.step('Navigate to Mail recovery', () => openMailRecovery(page));

    const inbox = await test.step('Read the native Zoho Inbox inventory', async () => {
      const nativeFolders = await mailApi.listFoldersAndMessages(email);
      const matchingInboxes = nativeFolders.filter((folder) =>
        folder.name.trim().toLowerCase() === 'inbox');
      const selectedInbox = matchingInboxes.find((folder) => folder.path.trim().toLowerCase() === 'inbox')
        ?? (matchingInboxes.length === 1 ? matchingInboxes[0] : undefined);
      if (!selectedInbox) {
        throw new Error(`Expected exactly one Zoho Mail Inbox, found ${matchingInboxes.length}.`);
      }
      return selectedInbox;
    });

    const downloadDirectory = join(homedir(), 'Downloads', 'ZohoMailExportInspection');
    await test.step('Prepare the download folder', async () => {
      await mkdir(downloadDirectory, { recursive: true });
    });

    const download = await test.step('Download the completed Inbox export', () =>
      mailPage.exportFolderAndDownload(email, inbox.name, downloadDirectory));
    console.log(`[Zoho C2C Mail] Preserved export ZIP for Explorer inspection: ${download.archivePath}`);

    const exportedMessages = await test.step('Read message headers from the downloaded ZIP', () =>
      readExportedMailMessages(download.archivePath));
    await test.step('Compare exported headers with the Zoho Inbox', async () => {
      const result = compareMailExportMessages(inbox.messages, exportedMessages);
      console.table([{
        Folder: inbox.path,
        ZohoInboxMessages: inbox.messages.length,
        DownloadedMessages: exportedMessages.length,
        MissingFromExport: result.nativeOnly.length,
        ExtraInExport: result.exportOnly.length,
      }]);
      expect(result.nativeOnly, 'Zoho Inbox contains messages missing from the downloaded export.').toEqual([]);
      expect(result.exportOnly, 'The downloaded Inbox export contains messages not found in Zoho Inbox.').toEqual([]);
    });
  });
});
